function Global.N_0x36c6984c3ed0c911(p0)
	return _in(0x36C6984C3ED0C911, p0)
end
