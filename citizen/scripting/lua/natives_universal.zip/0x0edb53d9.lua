function Global.N_0xbbf327ded94e4deb(modifierName)
	return _in(0xBBF327DED94E4DEB, _ts(modifierName))
end
