function Global.N_0xfa50f79257745e74(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xFA50F79257745E74, p0, p1, p2, p3, p4, p5, p6, _r, _ri)
end
