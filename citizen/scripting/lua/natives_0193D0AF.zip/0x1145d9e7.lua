function Global.ScInboxMessageGetDataInt(p0, context, out)
	return _in(0xA00EFE4082C4056E, p0, _ts(context), _ii(out) --[[ may be optional ]], _r)
end
