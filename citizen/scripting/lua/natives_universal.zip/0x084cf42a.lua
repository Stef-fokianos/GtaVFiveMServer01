--- One call found in the b617d scripts:
-- AUDIO::_8A694D7A68F8DC38(NETWORK::NET_TO_PED(l_3989._f26F[0/*1*/]), "CONV_INTERRUPT_QUIT_IT", "LESTER");
function Global.InterruptConversationAndPause(p0, p1, p2)
	return _in(0x8A694D7A68F8DC38, p0, _ts(p1), _ts(p2))
end
