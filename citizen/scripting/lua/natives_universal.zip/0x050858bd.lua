--- normalizedValue is from 0.0 - 1.0
-- p2 is always 1
function Global.ResetSpecialAbilityControlsCinematic(player, normalizedValue, p2)
	return _in(0xA0696A65F009EE18, player, normalizedValue, p2)
end
