function Global.SetWidescreenBorders(p0, p1)
	return _in(0xD7F4D54CF80AFA34, p0, p1)
end
