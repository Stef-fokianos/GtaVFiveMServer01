function Global.UgcGetCreatorNum()
	return _in(0x597F8DBA9B206FC7, _r, _ri)
end
