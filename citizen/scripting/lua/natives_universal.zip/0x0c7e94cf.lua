function Global.Leaderboards2ReadRankPrediction()
	return _in(0xC38DC1E90D22547C, _i, _i, _i, _r)
end
