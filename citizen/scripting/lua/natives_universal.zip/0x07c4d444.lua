function Global.NetworkSpentCarwash(p0, p1, p2, p3, p4)
	return _in(0xEC03C719DB2F4306, p0, p1, p2, p3, p4)
end
