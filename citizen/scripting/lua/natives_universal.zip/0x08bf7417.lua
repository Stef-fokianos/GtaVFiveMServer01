--- seems to be frequently used with the NETWORK::NET_TO_x natives, particularly with vehicles. It is often the only ROPE:: native in a script.
function Global.ActivatePhysics(entity)
	return _in(0x710311ADF0E20730, entity)
end
