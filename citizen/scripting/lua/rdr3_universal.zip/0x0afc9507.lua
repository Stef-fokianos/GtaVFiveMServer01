function Global.N_0x22741652985c84d0(p0, p1)
	return _in(0x22741652985C84D0, p0, p1)
end
