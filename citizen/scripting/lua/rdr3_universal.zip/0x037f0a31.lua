function Global.ChalAddGoalProgressIntByScoreId(p0, p1)
	return _in(0xDDBD560745B1EE9C, p0, p1)
end
