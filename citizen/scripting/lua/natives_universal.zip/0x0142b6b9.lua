--- Starts a task to check an entered string for profanity on the ROS/Social Club services.
-- See also: 1753344C770358AE, 82E4A58BABC15AE7.
function Global.ScProfanityCheckString(string, token)
	return _in(0x75632C5ECD7ED843, _ts(string), _ii(token) --[[ may be optional ]], _r)
end
