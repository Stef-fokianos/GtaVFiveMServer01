function Global.N_0x098036cab8373d36(p0)
	return _in(0x098036CAB8373D36, p0)
end
