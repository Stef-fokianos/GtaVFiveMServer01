function Global.GetEventData(p0, p1, p3)
	return _in(0x2902843FCD2B2D79, p0, p1, _i, p3, _r)
end
