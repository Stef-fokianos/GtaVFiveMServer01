function Global.RequestImap(imapHash)
	return _in(0x59767C5A7A9AE6DA, _ch(imapHash))
end
