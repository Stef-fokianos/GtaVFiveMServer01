function Global.TaskMoveInTraffic_4(p0, p1, p2, p3, p4, p5)
	return _in(0x79482C12482A860D, p0, p1, p2, p3, p4, p5)
end
