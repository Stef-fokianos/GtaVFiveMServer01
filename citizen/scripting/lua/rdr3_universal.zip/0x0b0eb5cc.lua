function Global.CompendiumGangBountyCaptured(p0)
	return _in(0x725D52F21A5E9E06, p0)
end
