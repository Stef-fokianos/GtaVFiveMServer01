function Global.AttachVehicleToTowTruck(towTruck, vehicle, p2, x, y, z)
	return _in(0x29A16F8D621C4508, towTruck, vehicle, p2, x, y, z)
end
