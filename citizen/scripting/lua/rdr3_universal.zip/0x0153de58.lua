function Global.TaskReviveTarget(p0, p1, p2)
	return _in(0x356088527D9EBAAD, p0, p1, p2)
end
