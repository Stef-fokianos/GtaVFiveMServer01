function Global.SetSynchronizedSceneOrigin(sceneID, x, y, z, roll, pitch, yaw, p7)
	return _in(0x6ACF6B7225801CD7, sceneID, x, y, z, roll, pitch, yaw, p7)
end
