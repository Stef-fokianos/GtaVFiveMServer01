function Global.PauseMenuIsContextActive(contextHash)
	return _in(0x84698AB38D0C6636, _ch(contextHash), _r)
end
