function Global.SetPlayerSimulateAiming(player, toggle)
	return _in(0xE0447DEF81CCDFD2, player, toggle)
end
