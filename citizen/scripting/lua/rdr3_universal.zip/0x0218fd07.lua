function Global.N_0x5708edd71b50c008(p0, p1, p2)
	return _in(0x5708EDD71B50C008, p0, p1, p2)
end
