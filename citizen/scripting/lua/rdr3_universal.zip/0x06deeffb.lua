function Global.SetCamNearClip(cam, nearClip)
	return _in(0xA924028272A61364, cam, nearClip)
end
