function Global.N_0x02e741e19e39628c(p0, p1)
	return _in(0x02E741E19E39628C, p0, p1)
end
