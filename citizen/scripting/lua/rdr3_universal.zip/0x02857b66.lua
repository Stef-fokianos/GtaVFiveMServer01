function Global.N_0xecd67e9fa677cccf(p0)
	return _in(0xECD67E9FA677CCCF, p0)
end
