function Global.N_0x9ef07cfbb19a9733()
	return _in(0x9EF07CFBB19A9733, _r, _ri)
end
