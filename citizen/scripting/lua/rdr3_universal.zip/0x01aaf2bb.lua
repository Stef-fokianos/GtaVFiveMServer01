function Global.N_0xdd1e1393d966d39a(p0, p1)
	return _in(0xDD1E1393D966D39A, p0, p1, _r, _ri)
end
