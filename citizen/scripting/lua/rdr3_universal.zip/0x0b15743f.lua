function Global.ForceLightningFlashAtCoords(x, y, z)
	return _in(0x67943537D179597C, x, y, z)
end
