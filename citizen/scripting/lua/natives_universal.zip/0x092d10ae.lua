--- NativeDB Parameter 0: Hash garageHash
function Global.IsAnyEntityEntirelyInsideGarage(garageHash, p1, p2, p3, p4)
	return _in(0x673ED815D6E323B7, garageHash, p1, p2, p3, p4, _r)
end
