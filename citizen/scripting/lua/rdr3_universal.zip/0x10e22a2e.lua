function Global.UnlockSetNew(unlockHash, toggle)
	return _in(0xA6D79C7AEF870A99, _ch(unlockHash), toggle)
end
