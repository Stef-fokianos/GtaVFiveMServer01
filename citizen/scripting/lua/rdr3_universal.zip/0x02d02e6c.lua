function Global.N_0x88b58b83a43a8cab(p0, p1, p2)
	return _in(0x88B58B83A43A8CAB, p0, p1, p2, _r, _ri)
end
