function Global.SetFormationPositionsTargetRadius(p0, p1)
	return _in(0x7CC7D3B7AF7FB71F, p0, p1, _r, _ri)
end
