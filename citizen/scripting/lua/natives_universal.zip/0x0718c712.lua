function Global.DoesShopPedApparelHaveRestrictionTag(componentHash, drawableSlotHash, componentId)
	return _in(0x341DE7ED1D2A1BFD, _ch(componentHash), _ch(drawableSlotHash), componentId, _r)
end
