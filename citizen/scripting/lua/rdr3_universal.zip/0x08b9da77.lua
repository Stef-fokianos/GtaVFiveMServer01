function Global.N_0x56e58d4d118fb45e(p0, p1)
	return _in(0x56E58D4D118FB45E, p0, p1, _r, _ri)
end
