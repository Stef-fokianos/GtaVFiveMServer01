function Global.N_0xc08cff658b2e51da(p0, p1)
	return _in(0xC08CFF658B2E51DA, p0, p1, _r, _ri)
end
