function Global.N_0x802092b07e3b1eea(p0, p1, p2, p3, p4)
	return _in(0x802092B07E3B1EEA, p0, p1, p2, p3, p4, _r, _ri)
end
