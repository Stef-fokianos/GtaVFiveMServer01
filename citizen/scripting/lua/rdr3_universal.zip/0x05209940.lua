function Global.GetFrameTime()
	return _in(0x5E72022914CE3C38, _r, _rf)
end
