function Global.N_0x41452e8a3b9c0c4b()
	return _in(0x41452E8A3B9C0C4B, _r, _ri)
end
