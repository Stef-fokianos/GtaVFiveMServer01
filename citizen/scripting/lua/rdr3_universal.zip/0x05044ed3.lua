function Global.N_0x50aa09a0da64e73c(p0, p1, p2, p3, p4, p5, p6)
	return _in(0x50AA09A0DA64E73C, p0, p1, p2, p3, p4, p5, p6)
end
