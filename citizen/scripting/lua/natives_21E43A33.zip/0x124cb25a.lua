function Global.N_0xb48fced898292e52(p0, p1, p2, p3, p4)
	return _in(0xB48FCED898292E52, p0, p1, p2, p3, _ii(p4) --[[ may be optional ]], _r, _ri)
end
