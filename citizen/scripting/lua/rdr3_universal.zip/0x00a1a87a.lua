function Global.N_0xfefddc6e8fdf8a75(p0, p1)
	return _in(0xFEFDDC6E8FDF8A75, p0, p1)
end
