function Global.N_0x73f1e4f6df26fe30(p0)
	return _in(0x73F1E4F6DF26FE30, p0)
end
