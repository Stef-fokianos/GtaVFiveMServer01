function Global.N_0x5d3c528b7a7df836(p0)
	return _in(0x5D3C528B7A7DF836, p0)
end
