function Global.N_0x1fda57e8908f2609(p0, p1, p2)
	return _in(0x1FDA57E8908F2609, p0, p1, p2)
end
