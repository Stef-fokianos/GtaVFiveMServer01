function Global.NetworkSetTalkerProximity(p0)
	return _in(0xCBF12D65F95AD686, p0)
end
