function Global.NetworkSetInFreeCamMode(toggle)
	return _in(0xFC18DB55AE19E046, toggle)
end
