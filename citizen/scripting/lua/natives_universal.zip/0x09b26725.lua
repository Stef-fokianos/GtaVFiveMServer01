function Global.SetPedHelmet(ped, canWearHelmet)
	return _in(0x560A43136EB58105, ped, canWearHelmet)
end
