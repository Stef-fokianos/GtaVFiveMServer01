--- GET_CURRENT_*
-- NativeDB Introduced: v1493
-- @param radioStationName :
function Global.N_0x34d66bc058019ce0(radioStationName)
	return _in(0x34D66BC058019CE0, _ts(radioStationName), _r, _ri)
end
