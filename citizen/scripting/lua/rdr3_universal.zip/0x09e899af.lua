function Global.N_0xc0b1c05b313693d1(p0, p1)
	return _in(0xC0B1C05B313693D1, p0, p1)
end
