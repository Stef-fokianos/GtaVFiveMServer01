function Global.CreateVolumeByHashWithCustomName(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
	return _in(0x1F85E4AC774A201E, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, _r, _ri)
end
