function Global.SetNightvision(Toggle)
	return _in(0x18F621F7A5B1F85D, Toggle)
end
