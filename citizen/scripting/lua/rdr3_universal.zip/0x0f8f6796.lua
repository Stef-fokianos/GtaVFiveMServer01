function Global.UgcIsLanguageSupported(languageId)
	return _in(0xF53E48461B71EECB, languageId, _r)
end
