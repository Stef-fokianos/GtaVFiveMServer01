function Global.EnterFlowBlock(p0, p1)
	return _in(0x3B7519720C9DCB45, p0, p1, _r, _ri)
end
