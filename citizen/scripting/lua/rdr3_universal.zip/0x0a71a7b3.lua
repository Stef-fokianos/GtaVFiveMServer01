function Global.DrawSprite(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)
	return _in(0xC9884ECADE94CB34, _ts(textureDict), _ts(textureName), screenX, screenY, width, height, heading, red, green, blue, alpha, p11)
end
