--- Clears players from the target list for the specified Mumble voice target ID.
-- @param targetId A Mumble voice target ID, ranging from 1..30 (inclusive).
function Global.MumbleClearVoiceTargetPlayers(targetId)
	return _in(0x912e21da, targetId)
end
