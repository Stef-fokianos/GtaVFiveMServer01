function Global.N_0x4662bfe01938d98d(p0, p1, p2, p3, p4)
	return _in(0x4662BFE01938D98D, p0, p1, p2, p3, p4)
end
