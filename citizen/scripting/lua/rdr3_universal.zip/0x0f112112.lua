function Global.N_0xe777ddf3e78397e8(p0)
	return _in(0xE777DDF3E78397E8, p0, _r, _ri)
end
