function Global.N_0xba751764f0821256()
	return _in(0xBA751764F0821256)
end
