function Global.N_0xd840c130d7aacfa5(p0, p1, p2)
	return _in(0xD840C130D7AACFA5, p0, p1, p2)
end
