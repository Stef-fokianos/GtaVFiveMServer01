function Global.N_0x44a5eef54f62e823(p0)
	return _in(0x44A5EEF54F62E823, p0, _r, _ri)
end
