--- Must be toggled before being queued for animation
function Global.SetBlipDisplayIndicatorOnBlip(blip, p1)
	return _in(0xC4278F70131BAA6D, blip, p1)
end
