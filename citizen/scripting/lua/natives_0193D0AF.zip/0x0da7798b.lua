--- A getter for [SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME](#_0xB3B3359379FE77D3).
-- Same as vehicle density multiplier.
-- @return Returns random vehicle density multiplier value.
function Global.GetRandomVehicleDensityMultiplier()
	return _in(0x7b0d00c5, _r, _rf)
end
