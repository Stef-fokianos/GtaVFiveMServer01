function Global.N_0x9935f76407c32539(p0)
	return _in(0x9935F76407C32539, _ts(p0))
end
