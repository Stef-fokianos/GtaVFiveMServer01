function Global.StopCutsceneAudio()
	return _in(0x806058BBDC136E06)
end
