function Global.NetworkSessionGetKickVote(player)
	return _in(0xD6D09A6F32F49EF1, player, _r)
end
