function Global.SetEveryoneIgnorePlayer(player, toggle)
	return _in(0x8EEDA153AD141BA4, player, toggle)
end
