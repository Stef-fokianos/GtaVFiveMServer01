function Global.N_0x920d853f3e17f1da(p0, p1)
	return _in(0x920D853F3E17F1DA, p0, p1)
end
