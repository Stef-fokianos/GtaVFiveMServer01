function Global.N_0xd61fcf9fcfd515b7(p0, p1, p2)
	return _in(0xD61FCF9FCFD515B7, p0, p1, p2)
end
