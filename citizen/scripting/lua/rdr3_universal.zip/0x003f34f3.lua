function Global.GetPlayerPed(player)
	return _in(0x275F255ED201B937, player, _r, _ri)
end
