function Global.N_0x9f6dcd0c939c71e9()
	return _in(0x9F6DCD0C939C71E9, _r, _ri)
end
