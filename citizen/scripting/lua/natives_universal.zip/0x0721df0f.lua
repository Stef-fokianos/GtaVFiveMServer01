--- NativeDB Return Type: void
function Global.SetNumberOfParkedVehicles(value)
	return _in(0xCAA15F13EBD417FF, value, _r, _ri)
end
