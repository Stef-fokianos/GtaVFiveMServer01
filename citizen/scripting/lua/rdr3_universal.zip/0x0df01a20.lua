function Global.N_0xa7966807953a18ee(p0, p1)
	return _in(0xA7966807953A18EE, p0, p1)
end
