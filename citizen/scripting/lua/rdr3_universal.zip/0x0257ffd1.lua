function Global.N_0xb9bdfae609dfb7c5(p0, p1, p2)
	return _in(0xB9BDFAE609DFB7C5, p0, p1, p2)
end
