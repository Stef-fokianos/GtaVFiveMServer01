function Global.NetworkGetOldestResendCountForPlayer()
	return _in(0x52C1EADAF7B10302, _r, _ri)
end
