function Global.N_0x38d9d50f2085e9b3(p0)
	return _in(0x38D9D50F2085E9B3, p0)
end
