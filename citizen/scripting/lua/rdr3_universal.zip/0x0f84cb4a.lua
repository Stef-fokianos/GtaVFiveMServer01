function Global.N_0xa3716a77dcf17424(p0, p1, p2)
	return _in(0xA3716A77DCF17424, p0, p1, p2)
end
