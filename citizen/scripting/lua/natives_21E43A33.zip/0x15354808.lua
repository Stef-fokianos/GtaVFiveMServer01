function Global.N_0x9ebc85ed0fffe51c(p0, p1, p2)
	return _in(0x9EBC85ED0FFFE51C, p0, p1, p2)
end
