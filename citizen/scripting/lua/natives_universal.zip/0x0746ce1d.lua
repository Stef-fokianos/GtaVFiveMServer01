function Global.GetReplayStatMissionType()
	return _in(0x2B626A0150E4D449, _r, _ri)
end
