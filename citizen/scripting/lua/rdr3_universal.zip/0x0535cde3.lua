function Global.N_0x9f348de670423460(p0)
	return _in(0x9F348DE670423460, p0)
end
