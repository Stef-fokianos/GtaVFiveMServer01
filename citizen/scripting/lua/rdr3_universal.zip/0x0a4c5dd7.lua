function Global.N_0x27af48c62b281341()
	return _in(0x27AF48C62B281341, _r, _ri)
end
