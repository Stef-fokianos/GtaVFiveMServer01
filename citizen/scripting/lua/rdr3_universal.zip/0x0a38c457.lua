function Global.N_0xaff2fd8add927585()
	return _in(0xAFF2FD8ADD927585)
end
