function Global.N_0x65499865fca6e5ec(doorHash)
	return _in(0x65499865FCA6E5EC, _ch(doorHash), _r, _rf)
end
