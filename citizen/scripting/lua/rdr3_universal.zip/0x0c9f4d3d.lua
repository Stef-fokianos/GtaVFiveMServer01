function Global.N_0xfb4891bd7578cdc1(p0, p1)
	return _in(0xFB4891BD7578CDC1, p0, p1, _r, _ri)
end
