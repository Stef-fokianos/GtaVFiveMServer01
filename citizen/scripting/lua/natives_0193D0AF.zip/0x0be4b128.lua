function Global.GetLiveryName(vehicle, liveryIndex)
	return _in(0xB4C7A93837C91A1F, vehicle, liveryIndex, _r, _s)
end
