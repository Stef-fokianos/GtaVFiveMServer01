function Global.SetFadeInAfterLoad(toggle)
	return _in(0xAC806C4CAB973517, toggle)
end
