function Global.IsScreenFadedOut()
	return _in(0xF5472C80DF2FF847, _r)
end
