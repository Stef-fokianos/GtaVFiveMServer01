--- Starts a new singleplayer game (at the prologue).
function Global.ShutdownAndLaunchSinglePlayerGame()
	return _in(0x593850C16A36B692)
end
