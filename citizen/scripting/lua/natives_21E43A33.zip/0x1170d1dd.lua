--- Use along with SetVehicleWheelWidth to resize the wheels (this native sets the collider width affecting physics while SetVehicleWheelWidth will change visual width).
-- @param vehicle The vehicle to obtain data for.
-- @param wheelIndex Index of wheel, 0-3.
-- @param value Width of tire collider.
function Global.SetVehicleWheelTireColliderWidth(vehicle, wheelIndex, value)
	return _in(0x47bd0270, vehicle, wheelIndex, value)
end
