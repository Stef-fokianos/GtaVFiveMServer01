function Global.N_0xe5a680a5d8b1f687(p0)
	return _in(0xE5A680A5D8B1F687, p0)
end
