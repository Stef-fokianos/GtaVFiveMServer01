--- Second parameter might be length.
function Global.StartSaveArrayWithSize(size, arrayName)
	return _in(0x60FE567DF1B1AF9D, _i, size, _ts(arrayName))
end
