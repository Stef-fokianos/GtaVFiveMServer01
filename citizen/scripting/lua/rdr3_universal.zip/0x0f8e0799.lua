--- Creates a blank runtime texture.
-- @param txd A handle to the runtime TXD to create the runtime texture in.
-- @param txn The name for the texture in the runtime texture dictionary.
-- @param width The width of the new texture.
-- @param height The height of the new texture.
-- @return A runtime texture handle.
function Global.CreateRuntimeTexture(txd, txn, width, height)
	return _in(0xfec3766d, txd, _ts(txn), width, height, _r, _rl)
end
