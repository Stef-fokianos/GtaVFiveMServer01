function Global.N_0xbec65c6049b3219d(p0, p1, p2, p3, p4, p5)
	return _in(0xBEC65C6049B3219D, p0, p1, p2, p3, p4, p5, _r, _ri)
end
