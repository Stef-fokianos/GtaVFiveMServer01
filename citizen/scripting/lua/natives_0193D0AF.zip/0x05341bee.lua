function Global.SetVehicleNeonLightEnabled(vehicle, index, toggle)
	return _in(0x2AA720E4287BF269, vehicle, index, toggle)
end
