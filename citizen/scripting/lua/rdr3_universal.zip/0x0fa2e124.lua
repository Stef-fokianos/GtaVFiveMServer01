function Global.N_0xb48050d326e9a2f3(p0)
	return _in(0xB48050D326E9A2F3, p0, _r, _ri)
end
