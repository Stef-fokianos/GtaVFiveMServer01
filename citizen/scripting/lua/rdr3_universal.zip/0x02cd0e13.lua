function Global.GetCurrentPedWeaponEntityIndex(ped, p1)
	return _in(0x3B390A939AF0B5FC, ped, p1, _r, _ri)
end
