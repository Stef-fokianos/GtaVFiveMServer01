function Global.N_0x078076ab50fb117f(p0, p1, p2, p3, p4, p5)
	return _in(0x078076AB50FB117F, p0, p1, p2, p3, p4, p5, _r, _ri)
end
