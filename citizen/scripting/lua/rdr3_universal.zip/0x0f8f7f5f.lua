function Global.N_0x39d6dace323a20b6(p0)
	return _in(0x39D6DACE323A20B6, p0, _r, _ri)
end
