function Global.N_0x4c11ccacb7c02b6e(p0)
	return _in(0x4C11CCACB7C02B6E, p0, _r, _ri)
end
