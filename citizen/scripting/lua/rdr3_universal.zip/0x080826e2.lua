function Global.TaskPickUpWeapon(p0, p1)
	return _in(0x55B0ECFD98596624, p0, p1)
end
