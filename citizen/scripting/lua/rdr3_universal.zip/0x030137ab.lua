function Global.N_0x423c6b1f3786d28b(p0, p1)
	return _in(0x423C6B1F3786D28B, p0, p1)
end
