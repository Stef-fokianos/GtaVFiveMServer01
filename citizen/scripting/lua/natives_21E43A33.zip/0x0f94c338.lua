function Global.NetworkAddFriend()
	return _in(0x8E02D73914064223, _i, _i, _r)
end
