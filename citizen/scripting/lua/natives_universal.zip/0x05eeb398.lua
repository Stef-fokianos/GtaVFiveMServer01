function Global.N_0xeb2bf817463dfa28(string, token)
	return _in(0xEB2BF817463DFA28, _ts(string), _ii(token) --[[ may be optional ]], _r)
end
