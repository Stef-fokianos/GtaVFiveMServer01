function Global.AddTrevorRandomModifier(p0)
	return _in(0x595B5178E412E199, p0, _r)
end
