function Global.N_0xeb709a36958abe0d(p0)
	return _in(0xEB709A36958ABE0D, p0, _r)
end
