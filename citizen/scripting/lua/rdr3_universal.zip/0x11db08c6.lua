function Global.N_0x897934e868eddd6c(p0, p1, p2, p3, p4)
	return _in(0x897934E868EDDD6C, p0, p1, p2, p3, p4)
end
