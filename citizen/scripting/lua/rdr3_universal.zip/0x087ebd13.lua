function Global.N_0xc08dff658b2e51db(p0)
	return _in(0xC08DFF658B2E51DB, p0, _r, _ri)
end
