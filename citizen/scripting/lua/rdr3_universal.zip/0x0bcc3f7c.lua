function Global.N_0xeba51a294c73292e(p0)
	return _in(0xEBA51A294C73292E, p0)
end
