function Global.N_0x76f7e1bcd623a429(p0)
	return _in(0x76F7E1BCD623A429, p0)
end
