function Global.N_0x95cbc65780de7eb1(p0, p1)
	return _in(0x95CBC65780DE7EB1, p0, p1, _r, _ri)
end
