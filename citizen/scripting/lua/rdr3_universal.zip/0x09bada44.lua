function Global.N_0x0556c784fa056628(p0, p1)
	return _in(0x0556C784FA056628, p0, p1, _r, _ri)
end
