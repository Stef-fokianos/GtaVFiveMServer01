function Global.N_0x61767f73eaceed21(ped)
	return _in(0x61767F73EACEED21, ped, _r)
end
