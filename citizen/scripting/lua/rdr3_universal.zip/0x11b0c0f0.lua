function Global.N_0x7d7285efeab5af15(p0, p1)
	return _in(0x7D7285EFEAB5AF15, p0, p1)
end
