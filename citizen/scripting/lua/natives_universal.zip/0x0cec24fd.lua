--- Probably SET_VEHICLE_SOMETHING
function Global.N_0xcda42c4bb9bde779(vehicle, p1)
	return _in(0xCDA42C4BB9BDE779, vehicle, p1)
end
