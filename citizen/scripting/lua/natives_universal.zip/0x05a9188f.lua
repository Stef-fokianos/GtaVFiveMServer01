function Global.NetworkClanDownloadMembershipPending(p0)
	return _in(0x5B9E023DC6EBEDC0, _ii(p0) --[[ may be optional ]], _r)
end
