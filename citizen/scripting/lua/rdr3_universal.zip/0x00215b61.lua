function Global.N_0x99c6ea66dfe73757(p0, p1, p2)
	return _in(0x99C6EA66DFE73757, p0, p1, p2, _r, _ri)
end
