function Global.N_0x36513affc703c60d(p0)
	return _in(0x36513AFFC703C60D, p0)
end
