function Global.N_0x27e3f2b57209fa54(p0, p1)
	return _in(0x27E3F2B57209FA54, p0, p1)
end
