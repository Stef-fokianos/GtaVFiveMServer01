--- You can only use text entries. No custom text.
-- ```
-- ```
-- NativeDB Added Parameter 11: Any p10
function Global.SetWarningMessageWithHeaderAndSubstringFlags(entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, p6, p9)
	return _in(0x701919482C74B5AB, _ts(entryHeader), _ts(entryLine1), instructionalKey, _ts(entryLine2), p4, p5, p6, _i, _i, p9)
end
