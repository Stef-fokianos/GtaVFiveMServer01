function Global.N_0x6d58167f62238284(p0)
	return _in(0x6D58167F62238284, p0, _r, _ri)
end
