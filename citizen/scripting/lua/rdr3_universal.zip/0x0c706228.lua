function Global.N_0xb285ad0ec870b2df(p0, p1)
	return _in(0xB285AD0EC870B2DF, p0, p1)
end
