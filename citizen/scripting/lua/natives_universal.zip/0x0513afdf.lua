--- Assigns some ambient voice to the ped.
function Global.SetPedScream(ped)
	return _in(0x40CF0D12D142A9E8, ped)
end
