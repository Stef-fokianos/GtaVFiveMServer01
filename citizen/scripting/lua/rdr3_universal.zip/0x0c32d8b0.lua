function Global.ClearFocus()
	return _in(0x86CCAF7CE493EFBE)
end
