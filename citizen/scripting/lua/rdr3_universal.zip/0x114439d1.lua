function Global.GetHashOfThisScriptName()
	return _in(0xBC2C927F5C264960, _r, _ri)
end
