function Global.N_0xb8e213d02f37947d(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xB8E213D02F37947D, p0, p1, p2, p3, p4, p5, p6)
end
