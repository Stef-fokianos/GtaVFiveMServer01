function Global.N_0xcd284e2f6ac27ee9(p0)
	return _in(0xCD284E2F6AC27EE9, p0)
end
