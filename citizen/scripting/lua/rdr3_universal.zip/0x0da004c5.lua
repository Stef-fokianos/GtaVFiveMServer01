function Global.TaskExtendRoute(x, y, z)
	return _in(0x1E7889778264843A, x, y, z)
end
