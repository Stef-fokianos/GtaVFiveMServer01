function Global.N_0x95384c6ce1526eff(p0, p1)
	return _in(0x95384C6CE1526EFF, p0, p1)
end
