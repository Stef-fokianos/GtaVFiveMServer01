function Global.N_0xd389a2549c4efb30(p0)
	return _in(0xD389A2549C4EFB30, p0, _r, _ri)
end
