function Global.N_0xe0884c184728c75b(p0, p1, p2, p3)
	return _in(0xE0884C184728C75B, p0, p1, p2, p3)
end
