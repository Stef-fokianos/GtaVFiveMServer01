function Global.N_0xb56d41a694e42e86(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xB56D41A694E42E86, p0, p1, p2, p3, p4, p5, p6)
end
