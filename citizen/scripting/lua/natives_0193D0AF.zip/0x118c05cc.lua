function Global.TaskSynchronizedScene(ped, scene, animDictionary, animationName, speed, speedMultiplier, duration, flag, playbackRate, p9)
	return _in(0xEEA929141F699854, ped, scene, _ts(animDictionary), _ts(animationName), speed, speedMultiplier, duration, flag, playbackRate, p9)
end
