function Global.N_0x6abc50979655bee7(p0, p1, p2)
	return _in(0x6ABC50979655BEE7, p0, p1, p2)
end
