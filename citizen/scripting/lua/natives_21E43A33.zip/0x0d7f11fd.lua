function Global.SetWind(p0)
	return _in(0xAC3A74E8384A9919, p0)
end
