--- This native sets a maximum speed for a vehicle.
-- @param vehicle The vehicle handle.
-- @param speed The speed limit in meters per second.
function Global.SetVehicleMaxSpeed(vehicle, speed)
	return _in(0xBAA045B4E42F3C06, vehicle, speed)
end
