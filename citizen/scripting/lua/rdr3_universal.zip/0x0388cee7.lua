function Global.N_0x49dadfc4cd808b0a(p0, p1, p2)
	return _in(0x49DADFC4CD808B0A, p0, p1, p2)
end
