function Global.IsVehicleNodeIdValid(vehicleNodeId)
	return _in(0x1EAF30FCFBF5AF74, vehicleNodeId, _r)
end
