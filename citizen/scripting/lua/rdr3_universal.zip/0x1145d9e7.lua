function Global.ScInboxMessageGetDataInt(p0, context, out)
	return _in(0x95BB39C4DA99F348, p0, _ts(context), _ii(out) --[[ may be optional ]], _r)
end
