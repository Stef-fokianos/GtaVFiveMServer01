function Global.N_0x6483c25849031c4f(p0, p1, p2, p3)
	return _in(0x6483C25849031C4F, p0, p1, p2, _ii(p3) --[[ may be optional ]])
end
