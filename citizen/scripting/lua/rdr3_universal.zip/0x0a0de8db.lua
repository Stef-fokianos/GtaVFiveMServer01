function Global.N_0x264e9a5cd78c338f(p0)
	return _in(0x264E9A5CD78C338F, p0)
end
