function Global.N_0xd2dfc9cca5596a11(p0)
	return _in(0xD2DFC9CCA5596A11, p0)
end
