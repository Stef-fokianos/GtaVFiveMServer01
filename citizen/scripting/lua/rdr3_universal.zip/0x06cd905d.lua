function Global.N_0x865fec2fa899f29c(p0)
	return _in(0x865FEC2FA899F29C, p0, _r, _ri)
end
