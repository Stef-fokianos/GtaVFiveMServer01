function Global.N_0x6569f31a01b4c097(p0, p1, p2)
	return _in(0x6569F31A01B4C097, p0, p1, p2)
end
