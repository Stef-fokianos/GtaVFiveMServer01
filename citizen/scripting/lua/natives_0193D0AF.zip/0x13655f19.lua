function Global.NetworkRemoveAllTransitionInvite()
	return _in(0x726E0375C7A26368)
end
