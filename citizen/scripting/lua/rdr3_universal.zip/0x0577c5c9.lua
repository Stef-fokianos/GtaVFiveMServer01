function Global.N_0x6a648d42bf271dc7(p0, p1, p2, p3, p4, p5)
	return _in(0x6A648D42BF271DC7, p0, p1, p2, p3, p4, p5)
end
