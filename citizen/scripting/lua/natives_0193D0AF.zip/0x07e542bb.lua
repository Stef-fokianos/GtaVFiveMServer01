function Global.N_0x07c61676e5bb52cd(p0)
	return _in(0x07C61676E5BB52CD, p0, _r, _ri)
end
