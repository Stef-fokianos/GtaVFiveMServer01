function Global.N_0x86fd10251a7118a4(p0, p1)
	return _in(0x86FD10251A7118A4, p0, p1, _r, _ri)
end
