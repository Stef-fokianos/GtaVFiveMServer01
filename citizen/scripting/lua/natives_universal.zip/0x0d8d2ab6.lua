--- netScene to scene
function Global.N_0x02c40bf885c567b6(netScene)
	return _in(0x02C40BF885C567B6, netScene, _r, _ri)
end
