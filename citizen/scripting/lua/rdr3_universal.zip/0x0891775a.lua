function Global.N_0x665161d250850a9f(p0)
	return _in(0x665161D250850A9F, p0, _r, _ri)
end
