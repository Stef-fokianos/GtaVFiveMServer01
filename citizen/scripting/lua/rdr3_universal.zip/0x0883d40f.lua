function Global.CreatePedOnMount(mount, modelHash, index, p3, p4, p5, p6)
	return _in(0xF89AA2BD01FC06B7, mount, _ch(modelHash), index, p3, p4, p5, p6, _r, _ri)
end
