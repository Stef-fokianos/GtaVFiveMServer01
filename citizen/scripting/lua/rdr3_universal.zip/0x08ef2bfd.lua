function Global.N_0x53764309c4618087(p0)
	return _in(0x53764309C4618087, p0, _r, _ri)
end
