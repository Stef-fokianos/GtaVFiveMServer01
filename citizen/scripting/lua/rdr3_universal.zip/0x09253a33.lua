function Global.IsPlayerRidingTrain(player)
	return _in(0x2FB0ACADA6A238DD, player, _r)
end
