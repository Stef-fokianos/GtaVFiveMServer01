--- Returns true if the entity is in between the minimum and maximum values for the 2d screen coords.
-- This means that it will return true even if the entity is behind a wall for example, as long as you're looking at their location.
-- Chipping
function Global.IsEntityOnScreen(entity)
	return _in(0xE659E47AF827484B, entity, _r)
end
