function Global.TaskGetOffBoat(p0, p1)
	return _in(0x9C00E77AF14B2DFF, p0, p1)
end
