function Global.N_0x91c9e2a0f9dd6dd4()
	return _in(0x91C9E2A0F9DD6DD4, _r, _ri)
end
