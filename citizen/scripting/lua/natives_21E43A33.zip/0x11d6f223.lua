function Global.N_0xa097ab275061fb21()
	return _in(0xA097AB275061FB21, _r, _ri)
end
