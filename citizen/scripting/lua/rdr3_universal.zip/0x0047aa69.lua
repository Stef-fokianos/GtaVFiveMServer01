function Global.N_0xf8d1d2dab6007eef(p0, p1)
	return _in(0xF8D1D2DAB6007EEF, p0, p1, _r, _ri)
end
