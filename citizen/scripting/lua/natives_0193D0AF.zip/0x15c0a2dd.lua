function Global.N_0x1e3f1b1b891a2aaa(p0, p1)
	return _in(0x1E3F1B1B891A2AAA, p0, p1)
end
