function Global.VehicleWaypointPlaybackOverrideSpeed(vehicle, speed)
	return _in(0x121F0593E0A431D7, vehicle, speed)
end
