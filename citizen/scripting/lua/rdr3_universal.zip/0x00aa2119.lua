function Global.N_0xf08e42bfa46bdff8(p0, p1)
	return _in(0xF08E42BFA46BDFF8, p0, p1, _r, _ri)
end
