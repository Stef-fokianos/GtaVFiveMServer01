--- NativeDB Introduced: v1290
-- @param data :
function Global.PlaystatsH2FmprepEnd(data)
	return _in(0xD8AFB345A9C5CCBB, _ii(data) --[[ may be optional ]])
end
