function Global.N_0x4ae07eba3462c5d5(p0, p1)
	return _in(0x4AE07EBA3462C5D5, p0, p1)
end
