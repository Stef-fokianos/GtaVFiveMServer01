function Global.SetFocusPosAndVel(x, y, z, offsetX, offsetY, offsetZ)
	return _in(0x25F6EF88664540E2, x, y, z, offsetX, offsetY, offsetZ)
end
