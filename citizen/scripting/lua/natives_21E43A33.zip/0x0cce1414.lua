function Global.Asin(p0)
	return _in(0xC843060B5765DCE7, p0, _r, _rf)
end
