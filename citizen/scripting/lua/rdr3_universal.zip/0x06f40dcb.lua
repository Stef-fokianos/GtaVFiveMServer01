function Global.N_0x7de4643157ad646c(p0)
	return _in(0x7DE4643157AD646C, p0)
end
