function Global.N_0x5d517b27cf6ecd04(id)
	return _in(0x5D517B27CF6ECD04, id)
end
