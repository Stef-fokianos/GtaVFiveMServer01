function Global.N_0x0dd051b1bf4b8bd6(p0)
	return _in(0x0DD051B1BF4B8BD6, p0, _r, _ri)
end
