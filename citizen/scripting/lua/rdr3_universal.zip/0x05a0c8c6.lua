function Global.N_0x118873dd538490b4(p0, p1)
	return _in(0x118873DD538490B4, p0, p1)
end
