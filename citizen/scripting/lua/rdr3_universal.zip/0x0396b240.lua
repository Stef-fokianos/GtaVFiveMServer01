function Global.N_0xf6b82fce03b43a37(p0, p1)
	return _in(0xF6B82FCE03B43A37, p0, p1)
end
