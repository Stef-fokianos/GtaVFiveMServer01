--- Returns the coordinates of another player.
-- Does not work if you enter your own player id as p0 (will return `(0.0, 0.0, 0.0)` in that case).
-- @param player The player id, MUST be another player.
-- @return A Vector3 containing the coordinates of another player.
function Global.NetworkGetPlayerCoords(player)
	return _in(0x125E6D638B8605D4, player, _r, _rv)
end
