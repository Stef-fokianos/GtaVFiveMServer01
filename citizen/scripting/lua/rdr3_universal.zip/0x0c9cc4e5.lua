function Global.SetEntityCollision(entity, toggle, keepPhysics)
	return _in(0xF66F820909453B8C, entity, toggle, keepPhysics)
end
