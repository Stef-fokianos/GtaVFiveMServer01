function Global.TaskClimb_2(p0, p1)
	return _in(0xDF1D85BCAF60D537, p0, p1)
end
