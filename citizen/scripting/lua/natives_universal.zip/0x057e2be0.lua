function Global.GetVehicleDefaultHornIgnoreMods(vehicle)
	return _in(0xACB5DCCA1EC76840, vehicle, _r, _ri)
end
