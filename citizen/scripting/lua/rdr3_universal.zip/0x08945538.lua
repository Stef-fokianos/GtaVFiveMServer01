function Global.N_0x5ca6bbd4a7d8145e(p0)
	return _in(0x5CA6BBD4A7D8145E, p0, _r, _ri)
end
