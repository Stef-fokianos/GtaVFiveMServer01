function Global.N_0xb8ab265426cfe6dd(p0, p1)
	return _in(0xB8AB265426CFE6DD, p0, p1)
end
