function Global.GetWeatherTypeTransition()
	return _in(0x0AC679B2342F14F2, _i, _i, _f)
end
