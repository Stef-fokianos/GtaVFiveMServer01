function Global.N_0x2bf66d2e7414f686()
	return _in(0x2BF66D2E7414F686, _r, _ri)
end
