function Global.N_0xef259aa1e097e0ad(p0, p1)
	return _in(0xEF259AA1E097E0AD, p0, p1)
end
