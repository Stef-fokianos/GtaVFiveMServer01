function Global.N_0xfb6eb8785f808551(player, p1, p2)
	return _in(0xFB6EB8785F808551, player, p1, p2, _r)
end
