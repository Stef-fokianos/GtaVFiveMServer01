function Global.N_0x9eca15adfe141431()
	return _in(0x9ECA15ADFE141431, _r, _ri)
end
