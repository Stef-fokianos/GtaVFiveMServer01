--- native only found once in appinternet.c4
-- same thing as this but does not need websiteID
-- Any _0xE3B05614DCE1D014(Any p0) // 0xE3B05614DCE1D014 0xD217EE7E
-- returns current websitePageID
function Global.N_0x01a358d9128b7a86()
	return _in(0x01A358D9128B7A86, _r, _ri)
end
