function Global.N_0x5c9c3a466b3296a8(p0)
	return _in(0x5C9C3A466B3296A8, p0, _r, _ri)
end
