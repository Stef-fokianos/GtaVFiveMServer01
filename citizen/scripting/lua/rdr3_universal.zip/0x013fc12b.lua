function Global.DatabindingAddUiItemListFromPath(p0, p1)
	return _in(0xDB5B9A474148F699, p0, p1, _r, _ri)
end
