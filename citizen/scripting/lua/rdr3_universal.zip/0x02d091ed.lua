function Global.N_0x5d1c5d8e62e8ee1c(p0)
	return _in(0x5D1C5D8E62E8EE1C, p0, _r, _ri)
end
