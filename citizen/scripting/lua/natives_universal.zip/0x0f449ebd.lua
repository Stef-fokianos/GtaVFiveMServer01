--- NativeDB Introduced: v1290
-- @param amount :
-- @param p1 :
function Global.NetworkEarnFromTargetRefund(amount, p1)
	return _in(0x5B669CF2299A271F, amount, p1)
end
