function Global.N_0x031acb6aba18c729(radioStation, p1)
	return _in(0x031ACB6ABA18C729, _ts(radioStation), _ts(p1))
end
