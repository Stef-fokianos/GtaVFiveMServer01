--- Only 1 match. Both p1 & p2 were true.
function Global.SpecialAbilityChargeMedium(player, p1, p2)
	return _in(0xF113E3AA9BC54613, player, p1, p2)
end
