function Global.N_0x4c60c333f9cca2b6(p0, p1)
	return _in(0x4C60C333F9CCA2B6, p0, p1)
end
