function Global.N_0xf4ac4fa844fd559a(p0)
	return _in(0xF4AC4FA844FD559A, p0, _r, _ri)
end
