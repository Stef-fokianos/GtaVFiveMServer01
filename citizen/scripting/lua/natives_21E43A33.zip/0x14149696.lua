function Global.AddCamSplineNode(camera, x, y, z, xRot, yRot, zRot, p7, p8, p9)
	return _in(0x8609C75EC438FB3B, camera, x, y, z, xRot, yRot, zRot, p7, p8, p9)
end
