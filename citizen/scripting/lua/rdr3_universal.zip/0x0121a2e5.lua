function Global.N_0x3f73aed12a5ef0ff(p0)
	return _in(0x3F73AED12A5EF0FF, p0, _r, _ri)
end
