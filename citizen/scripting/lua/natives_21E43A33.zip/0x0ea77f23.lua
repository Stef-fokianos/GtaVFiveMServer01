function Global.N_0xf51d36185993515d(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xF51D36185993515D, p0, p1, p2, p3, p4, p5, p6)
end
