--- NativeDB Return Type: BOOL
function Global.NetGameserverDeleteSetTelemetryNonceSeed()
	return _in(0x112CEF1615A1139F, _r, _ri)
end
