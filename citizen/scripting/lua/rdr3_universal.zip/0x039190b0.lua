function Global.N_0x04aa59ca40571c2e(p0, p1)
	return _in(0x04AA59CA40571C2E, p0, p1, _r, _ri)
end
