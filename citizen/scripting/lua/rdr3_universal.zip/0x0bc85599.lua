function Global.TaskAimAtCoord(p0, p1, p2, p3, p4, p5, p6)
	return _in(0x4AF1D73861212F52, p0, p1, p2, p3, p4, p5, p6)
end
