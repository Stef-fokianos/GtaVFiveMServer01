function Global.GetVehicleLandingGear(vehicle)
	return _in(0x9B0F3DCA3DB0F4CD, vehicle, _r, _ri)
end
