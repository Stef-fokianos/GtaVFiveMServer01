function Global.N_0xec116edb683ad479(p0)
	return _in(0xEC116EDB683AD479, p0)
end
