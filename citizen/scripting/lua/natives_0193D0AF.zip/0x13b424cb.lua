function Global.N_0x6f697a66ce78674e(team, toggle)
	return _in(0x6F697A66CE78674E, team, toggle)
end
