function Global.N_0x5ebe38a20bc51c27(p0)
	return _in(0x5EBE38A20BC51C27, p0, _r, _ri)
end
