function Global.DetachAnimScene(animScene)
	return _in(0x6843A1AA3A336DFF, animScene)
end
