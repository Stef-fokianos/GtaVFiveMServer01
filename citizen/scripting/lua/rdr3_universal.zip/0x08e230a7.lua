function Global.StartShapeTestSweptSphere(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in(0xAA5B7C8309F73230, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _r, _ri)
end
