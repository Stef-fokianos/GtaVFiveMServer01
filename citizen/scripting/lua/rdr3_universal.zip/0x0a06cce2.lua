function Global.N_0x632be8d84846fa56()
	return _in(0x632BE8D84846FA56)
end
