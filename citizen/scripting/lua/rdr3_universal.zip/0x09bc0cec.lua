function Global.N_0xa691c10054275290(p0, p1, p2)
	return _in(0xA691C10054275290, p0, p1, p2)
end
