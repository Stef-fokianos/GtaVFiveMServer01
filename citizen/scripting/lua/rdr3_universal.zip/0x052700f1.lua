function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return _in(0xC932F57F31EA9152, player, _r)
end
