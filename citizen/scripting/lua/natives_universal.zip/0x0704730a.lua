function Global.SetVehicleKersAllowed(vehicle, toggle)
	return _in(0x99C82F8A139F3E4E, vehicle, toggle)
end
