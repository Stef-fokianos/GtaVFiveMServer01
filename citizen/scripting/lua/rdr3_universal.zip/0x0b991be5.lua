function Global.LogAddOrUpdateObjective(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xB43163388484CC87, p0, p1, p2, p3, p4, p5, p6)
end
