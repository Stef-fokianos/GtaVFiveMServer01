function Global.CreateModelSwap(x, y, z, radius, originalModel, newModel, p6)
	return _in(0x92C47782FDA8B2A3, x, y, z, radius, _ch(originalModel), _ch(newModel), p6)
end
