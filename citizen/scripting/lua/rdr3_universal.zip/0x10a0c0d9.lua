function Global.N_0xb40ea9e0d2e2f7f3(p0, p1)
	return _in(0xB40EA9E0D2E2F7F3, p0, p1)
end
