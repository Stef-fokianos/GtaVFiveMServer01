function Global.N_0xc0258742b034dfaf(p0)
	return _in(0xC0258742B034DFAF, p0)
end
