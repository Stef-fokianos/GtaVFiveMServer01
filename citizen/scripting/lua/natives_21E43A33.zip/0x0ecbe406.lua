function Global.NetworkSessionGetInviter(p0)
	return _in(0xE57397B4A3429DD0, _ii(p0) --[[ may be optional ]])
end
