function Global.N_0x975f6ebb62632fe3()
	return _in(0x975F6EBB62632FE3, _r, _ri)
end
