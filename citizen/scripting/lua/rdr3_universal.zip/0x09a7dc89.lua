function Global.N_0x104d9a7b1c0d0783(p0, p1)
	return _in(0x104D9A7B1C0D0783, p0, p1)
end
