function Global.N_0xd9b71952f78a2640(doorHash, p1)
	return _in(0xD9B71952F78A2640, _ch(doorHash), p1)
end
