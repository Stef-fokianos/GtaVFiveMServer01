function Global.StopAllAlarms(stop)
	return _in(0x2F794A877ADD4C92, stop)
end
