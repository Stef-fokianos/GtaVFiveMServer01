function Global.ScProfanityCheckString(string, token)
	return _in(0x9C74AC9D87B3FFF4, _ts(string), _ii(token) --[[ may be optional ]], _r)
end
