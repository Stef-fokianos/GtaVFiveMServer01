function Global.N_0x00ffe0f85253c572(p0)
	return _in(0x00FFE0F85253C572, p0, _r, _ri)
end
