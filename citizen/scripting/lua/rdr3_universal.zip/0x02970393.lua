function Global.SetVehicleExplodesOnHighExplosionDamage(vehicle, toggle)
	return _in(0xA402939C6761E1A3, vehicle, toggle)
end
