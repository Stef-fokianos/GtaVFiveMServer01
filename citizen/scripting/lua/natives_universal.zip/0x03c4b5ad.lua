--- NativeDB Parameter 0: Hash garageHash
function Global.AreEntitiesEntirelyInsideGarage(garageHash, p1, p2, p3, p4)
	return _in(0x85B6C850546FDDE2, garageHash, p1, p2, p3, p4, _r)
end
