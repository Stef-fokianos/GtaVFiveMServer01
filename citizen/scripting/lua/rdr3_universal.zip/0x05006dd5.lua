function Global.IsPedFleeing(ped)
	return _in(0xBBCCE00B381F8482, ped, _r)
end
