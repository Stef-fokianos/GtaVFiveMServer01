function Global.RemovePopMultiplierSphere(id, p1)
	return _in(0xE6869BECDD8F2403, id, p1)
end
