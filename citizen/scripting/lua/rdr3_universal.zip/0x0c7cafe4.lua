function Global.N_0x42688e94e96fd9b4(p0, p1, p2)
	return _in(0x42688E94E96FD9B4, p0, p1, p2, _r, _ri)
end
