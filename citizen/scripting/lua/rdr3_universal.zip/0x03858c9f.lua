function Global.CreateIncident(dispatchService, x, y, z, numUnits, radius, p7, p8)
	return _in(0x3F892CAF67444AE7, dispatchService, x, y, z, numUnits, radius, _i, p7, p8, _r)
end
