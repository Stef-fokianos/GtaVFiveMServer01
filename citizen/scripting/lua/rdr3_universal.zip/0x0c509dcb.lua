function Global.N_0xb1f6665aa54dcd5c(p0)
	return _in(0xB1F6665AA54DCD5C, p0, _r, _ri)
end
