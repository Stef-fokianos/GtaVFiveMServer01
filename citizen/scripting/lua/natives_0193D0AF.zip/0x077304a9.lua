function Global.UnlockMissionNewsStory(newsStory)
	return _in(0xB165AB7C248B2DC1, newsStory)
end
