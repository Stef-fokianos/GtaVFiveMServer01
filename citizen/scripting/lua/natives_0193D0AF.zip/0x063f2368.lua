function Global.N_0xd2dccd8e16e20997(p0)
	return _in(0xD2DCCD8E16E20997, p0)
end
