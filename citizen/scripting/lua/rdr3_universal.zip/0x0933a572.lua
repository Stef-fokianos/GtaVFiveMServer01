function Global.N_0x6818d1a194e29983()
	return _in(0x6818D1A194E29983, _r, _ri)
end
