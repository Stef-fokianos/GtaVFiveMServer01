function Global.N_0xd4ee21b7cc7fd350(p0)
	return _in(0xD4EE21B7CC7FD350, p0)
end
