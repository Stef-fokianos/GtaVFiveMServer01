function Global.SetPedGestureGroup(ped, p1)
	return _in(0xDDF803377F94AAA8, ped, _ii(p1) --[[ may be optional ]])
end
