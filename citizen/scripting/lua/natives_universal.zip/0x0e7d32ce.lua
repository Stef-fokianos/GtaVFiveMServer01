--- get's line count
-- int GetLineCount(char *text, float x, float y)
-- {
-- _BEGIN_TEXT_COMMAND_LINE_COUNT("STRING");
-- ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
-- return _END_TEXT_COMMAND_GET_LINE_COUNT(x, y);
-- }
function Global.SetTextGxtEntry(entry)
	return _in(0x521FB041D93DD0E4, _ts(entry))
end
