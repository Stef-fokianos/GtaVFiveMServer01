function Global.NetworkIsCloudBackgroundScriptRequestPending()
	return _in(0x8132C0EB8B2B3293, _r)
end
