function Global.N_0xe7282390542f570d(p0)
	return _in(0xE7282390542F570D, p0, _r, _ri)
end
