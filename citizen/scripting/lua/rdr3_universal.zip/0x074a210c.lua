function Global.AddShockingEventAtPosition(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
	return _in(0xD9F8455409B525E9, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, _r, _ri)
end
