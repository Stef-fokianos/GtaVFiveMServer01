--- parachuteModel = 230075693
function Global.SetVehicleParachuteModel(vehicle, modelHash)
	return _in(0x4D610C6B56031351, vehicle, _ch(modelHash))
end
