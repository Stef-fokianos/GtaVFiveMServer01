function Global.N_0xff9052bc7a3b7d33(p0, p1, p2, p3)
	return _in(0xFF9052BC7A3B7D33, p0, p1, p2, p3)
end
