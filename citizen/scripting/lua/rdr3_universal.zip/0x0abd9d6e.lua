function Global.SpactionproxyGetNextPendingBuyAction(data)
	return _in(0x1F471B79ACC98BEF, _ii(data) --[[ may be optional ]], _r)
end
