--- This is used to add a speedzone on a position.
-- Example usage C#:
-- uint speedZone = Function.Call<uint>((Hash) 0x2CE544C68FB812A0, Game.PlayerPed.Position.X, Game.PlayerPed.Position.Y, Game.PlayerPed.Position.Z, 100.0f, 0.0f, false);
-- (Thanks to alexguirre for his help!)
-- ==========================================
-- What is the point in adding a speed zone? Does it just generally affect the speed NPCs will drive? I can imagine running this on every section of the interstate setting it to 3 MPH rip.
function Global.AddSpeedZoneForCoord(x, y, z, radius, speed, p5)
	return _in(0x2CE544C68FB812A0, x, y, z, radius, speed, p5, _r, _ri)
end
