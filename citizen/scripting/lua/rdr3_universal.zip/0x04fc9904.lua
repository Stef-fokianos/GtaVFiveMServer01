function Global.N_0x31167ed4324b758d(p0)
	return _in(0x31167ED4324B758D, p0, _r, _ri)
end
