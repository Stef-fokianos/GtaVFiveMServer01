function Global.N_0xff8018c778349234(p0)
	return _in(0xFF8018C778349234, p0)
end
