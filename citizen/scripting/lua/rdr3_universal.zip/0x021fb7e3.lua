function Global.GetPlayerCurrentStealthNoise(player)
	return _in(0xD7ECC25E176ECBA5, player, _r, _rf)
end
