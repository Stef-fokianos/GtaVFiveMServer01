function Global.NetworkHashFromPlayerHandle(player)
	return _in(0xBC1D768F2F5D6C05, player, _r, _ri)
end
