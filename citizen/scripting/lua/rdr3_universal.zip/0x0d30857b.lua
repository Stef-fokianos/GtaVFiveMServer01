function Global.DatabindingWriteDataBool(p0, p1)
	return _in(0xAB888B4B91046770, p0, p1)
end
