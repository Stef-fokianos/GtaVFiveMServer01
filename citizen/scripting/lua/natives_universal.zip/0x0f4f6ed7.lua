--- Judging purely from a quick disassembly, if the ped is in a vehicle, the ped will be deleted immediately. If not, it'll be marked as no longer needed. - very elegant..
function Global.RemovePedElegantly(ped)
	return _in(0xAC6D445B994DF95E, _ii(ped) --[[ may be optional ]])
end
