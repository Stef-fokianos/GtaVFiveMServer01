function Global.SetHdArea(x, y, z, radius)
	return _in(0xB88B905AFA35CB4D, x, y, z, radius)
end
