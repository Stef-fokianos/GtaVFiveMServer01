function Global.PlayEndCreditsMusic(play)
	return _in(0xCD536C4D33DCC900, play)
end
