function Global.DisableControlAction(padIndex, control, disable)
	return _in(0xFE99B66D079CF6BC, padIndex, _ch(control), disable)
end
