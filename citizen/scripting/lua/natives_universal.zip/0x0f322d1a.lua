function Global.ShapeTestResultEntity(entityHit)
	return _in(0x2B3334BCA57CD799, entityHit)
end
