function Global.N_0x1280804f7cfd2d6c(ped)
	return _in(0x1280804F7CFD2D6C, ped)
end
