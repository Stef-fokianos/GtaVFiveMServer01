function Global.VirtualCollectionSetInterestIndex(p0, p1)
	return _in(0x49A8447533308BCF, p0, p1)
end
