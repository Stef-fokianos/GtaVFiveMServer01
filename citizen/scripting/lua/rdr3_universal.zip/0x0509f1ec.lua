function Global.N_0xfb680a9b33d0edbe(p0)
	return _in(0xFB680A9B33D0EDBE, p0)
end
