function Global.N_0x914071ff93af2692(p0, p1)
	return _in(0x914071FF93AF2692, p0, p1)
end
