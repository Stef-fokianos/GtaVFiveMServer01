function Global.HasActionModeAssetLoaded(asset)
	return _in(0xE4B5F4BF2CB24E65, _ts(asset), _r)
end
