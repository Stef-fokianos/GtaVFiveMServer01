function Global.N_0xfe53b1f8d43f19bf(p0, p1)
	return _in(0xFE53B1F8D43F19BF, p0, p1, _r, _ri)
end
