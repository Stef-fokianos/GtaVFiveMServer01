function Global.N_0xd42514c182121c23(p0)
	return _in(0xD42514C182121C23, p0, _r, _ri)
end
