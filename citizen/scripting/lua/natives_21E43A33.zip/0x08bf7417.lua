function Global.ActivatePhysics(entity)
	return _in(0x710311ADF0E20730, entity)
end
