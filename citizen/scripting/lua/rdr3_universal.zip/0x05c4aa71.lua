function Global.N_0xc061e50f8d299f95(p0, p1, p2, p3)
	return _in(0xC061E50F8D299F95, p0, p1, p2, p3, _r, _ri)
end
