function Global.N_0x09ee00b8f858e0be(p0, p1, p2, p3, p4, p5, p6)
	return _in(0x09EE00B8F858E0BE, p0, p1, p2, p3, p4, p5, p6, _r, _ri)
end
