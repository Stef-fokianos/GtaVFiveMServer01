--- returns the same value as NETWORK::GET_NETWORK_TIME in freemode.
function Global.GetNetworkTimeAccurate()
	return _in(0x89023FBBF9200E9F, _r, _ri)
end
