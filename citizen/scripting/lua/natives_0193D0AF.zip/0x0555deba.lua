function Global.IsEntityAttachedToAnyVehicle(entity)
	return _in(0x26AA915AD89BFB4B, entity, _r)
end
