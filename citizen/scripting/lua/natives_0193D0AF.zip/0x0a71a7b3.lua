function Global.DrawSprite(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha)
	return _in(0xE7FFAE5EBF23D890, _ts(textureDict), _ts(textureName), screenX, screenY, width, height, heading, red, green, blue, alpha)
end
