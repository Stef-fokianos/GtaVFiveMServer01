function Global.Absi(value)
	return _in(0x0C214D5B8A38C828, value, _r, _ri)
end
