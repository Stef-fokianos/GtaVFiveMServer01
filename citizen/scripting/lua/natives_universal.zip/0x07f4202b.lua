function Global.AddPointToGpsCustomRoute(x, y, z)
	return _in(0x311438A071DD9B1A, x, y, z)
end
