function Global.N_0x1148f706cf4ebdda(p0, p1, p2)
	return _in(0x1148F706CF4EBDDA, p0, p1, p2, _r, _ri)
end
