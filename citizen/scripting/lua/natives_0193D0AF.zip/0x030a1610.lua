function Global.N_0x2a25adc48f87841f()
	return _in(0x2A25ADC48F87841F, _r, _ri)
end
