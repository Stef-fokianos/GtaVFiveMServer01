function Global.N_0x7dfb49bcdb73089a(p0, p1)
	return _in(0x7DFB49BCDB73089A, p0, p1)
end
