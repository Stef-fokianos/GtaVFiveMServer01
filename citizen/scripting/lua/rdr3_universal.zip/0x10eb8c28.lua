function Global.TaskCower(p0, p1, p2, p3)
	return _in(0x3EB1FE9E8E908E15, p0, p1, p2, p3)
end
