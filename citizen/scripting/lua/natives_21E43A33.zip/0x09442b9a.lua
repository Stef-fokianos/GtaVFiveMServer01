function Global.NetworkSessionCancelInvite()
	return _in(0x2FBF47B1B36D36F9)
end
