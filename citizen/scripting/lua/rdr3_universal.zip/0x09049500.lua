function Global.N_0x462c687bea254bd9(p0)
	return _in(0x462C687BEA254BD9, p0, _r, _ri)
end
