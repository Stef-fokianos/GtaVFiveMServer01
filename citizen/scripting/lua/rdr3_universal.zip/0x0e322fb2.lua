function Global.N_0x0ada3ec589e1736e()
	return _in(0x0ADA3EC589E1736E)
end
