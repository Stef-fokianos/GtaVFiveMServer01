function Global.N_0x93ffd92f05ec32fd(p0)
	return _in(0x93FFD92F05EC32FD, p0, _r, _ri)
end
