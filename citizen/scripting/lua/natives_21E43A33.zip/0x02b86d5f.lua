function Global.ShutdownAndLaunchSinglePlayerGame()
	return _in(0x593850C16A36B692)
end
