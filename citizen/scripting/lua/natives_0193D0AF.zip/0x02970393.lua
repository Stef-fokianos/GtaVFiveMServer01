function Global.SetVehicleExplodesOnHighExplosionDamage(vehicle, toggle)
	return _in(0x71B0892EC081D60A, vehicle, toggle)
end
