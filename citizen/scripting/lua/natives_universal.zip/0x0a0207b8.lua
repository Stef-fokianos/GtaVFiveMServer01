--- NativeDB Introduced: v1493
-- @param ped :
-- @param toggle :
function Global.N_0x29da3ca8d8b2692d(ped, toggle)
	return _in(0x29DA3CA8D8B2692D, ped, toggle)
end
