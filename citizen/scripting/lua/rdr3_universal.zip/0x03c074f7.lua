function Global.N_0x58f2244c1286d09a(p0, p1)
	return _in(0x58F2244C1286D09A, p0, p1, _r, _ri)
end
