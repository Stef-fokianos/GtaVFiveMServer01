function Global.TaskVehicleDriveToDestination_2(p0, p1, p2, p3, p4, p5, p6, p7, p8)
	return _in(0x391073B9D3CCE2BA, p0, p1, p2, p3, p4, p5, p6, p7, p8)
end
