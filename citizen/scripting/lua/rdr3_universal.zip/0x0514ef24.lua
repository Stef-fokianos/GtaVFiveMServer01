function Global.N_0x5463c962bc7777c3(p0, p1, p2, p3, p4)
	return _in(0x5463C962BC7777C3, p0, p1, p2, p3, p4, _r, _ri)
end
