--- Sets vehicle's wheels' width (width is the same for all the wheels, cannot get/set specific wheel of vehicle).
-- Only works on non-default wheels.
-- Returns whether change was successful (can be false if trying to set width for non-default wheels).
-- @param vehicle The vehicle to set data for.
-- @param width Width of the wheels (usually between 0.1 and 1.5 is reasonable).
-- @return Bool - whether change was successful or not
function Global.SetVehicleWheelWidth(vehicle, width)
	return _in(0x64c3f1c0, vehicle, width, _r)
end
