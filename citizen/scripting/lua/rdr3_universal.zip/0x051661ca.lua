function Global.N_0xa6f67bec53379a32(p0, p1)
	return _in(0xA6F67BEC53379A32, p0, p1)
end
