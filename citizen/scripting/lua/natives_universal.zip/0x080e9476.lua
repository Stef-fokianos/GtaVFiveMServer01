--- Raycast from point to point, where the ray has a radius.
-- flags:
-- vehicles=10
-- peds =12
-- Iterating through flags yields many ped / vehicle/ object combinations
-- p9 = 7, but no idea what it does
-- Entity is an entity to ignore
function Global.StartShapeTestCapsule(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in(0x28579D1B8F8AAC80, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _r, _ri)
end
