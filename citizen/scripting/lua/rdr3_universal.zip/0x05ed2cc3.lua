function Global.WaypointPlaybackOverrideSpeed(p0, p1, p2, p3, p4)
	return _in(0x7D7D2B47FA788E85, p0, p1, p2, p3, p4)
end
