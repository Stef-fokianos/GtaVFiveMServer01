function Global.UgcGetContentHasPlayerRecord(p0)
	return _in(0x70EA8DA57840F9BE, p0, _r)
end
