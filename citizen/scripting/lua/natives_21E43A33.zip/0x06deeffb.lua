function Global.SetCamNearClip(cam, nearClip)
	return _in(0xC7848EFCCC545182, cam, nearClip)
end
