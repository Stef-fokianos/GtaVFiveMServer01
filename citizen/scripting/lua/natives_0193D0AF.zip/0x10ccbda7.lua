function Global.CreateIncidentWithEntity(incidentType, ped, amountOfPeople, radius, outIncidentID)
	return _in(0x05983472F0494E60, incidentType, ped, amountOfPeople, radius, _ii(outIncidentID) --[[ may be optional ]], _r)
end
