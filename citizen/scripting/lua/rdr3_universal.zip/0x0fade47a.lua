--- Hashed version of BG_START_CONTEXT
-- @param contextHash :
function Global.BgStartContextHash(contextHash)
	return _in(0x2EB67D564DCC09D5, _ch(contextHash))
end
