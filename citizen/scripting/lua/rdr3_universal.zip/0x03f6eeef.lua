function Global.N_0x10c70a515bc03707(p0)
	return _in(0x10C70A515BC03707, p0, _r, _ri)
end
