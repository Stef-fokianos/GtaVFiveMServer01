function Global.N_0xf7ea250b9a919e03(p0, p1)
	return _in(0xF7EA250B9A919E03, p0, p1)
end
