function Global.N_0xd3a6a0ef48823a8c()
	return _in(0xD3A6A0EF48823A8C, _r, _ri)
end
