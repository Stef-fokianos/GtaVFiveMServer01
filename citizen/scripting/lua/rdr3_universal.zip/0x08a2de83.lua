function Global.N_0x8fb7c254cfcbf78e(p0)
	return _in(0x8FB7C254CFCBF78E, p0, _r, _ri)
end
