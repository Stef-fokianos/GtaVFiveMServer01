function Global.N_0x97b06669ac569003(p0, p1)
	return _in(0x97B06669AC569003, p0, p1)
end
