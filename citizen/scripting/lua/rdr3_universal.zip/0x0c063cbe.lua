function Global.N_0xbfff81e12a745a5f()
	return _in(0xBFFF81E12A745A5F)
end
