function Global.N_0xdf947fe0d551684e(p0, p1)
	return _in(0xDF947FE0D551684E, p0, p1, _r, _ri)
end
