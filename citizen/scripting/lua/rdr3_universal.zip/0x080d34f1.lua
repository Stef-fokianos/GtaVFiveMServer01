function Global.SetPedGestureGroup(p0, p1, p2)
	return _in(0xDDF803377F94AAA8, p0, p1, p2)
end
