function Global.N_0x9f9a829c6751f3c7(p0, p1, p2)
	return _in(0x9F9A829C6751F3C7, p0, p1, p2)
end
