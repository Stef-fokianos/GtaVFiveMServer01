function Global.N_0x4248ab2eeb3c75ad(p0, p1, p2)
	return _in(0x4248AB2EEB3C75AD, p0, p1, p2)
end
