function Global.SetParticleFxNonLoopedColour(r, g, b)
	return _in(0x60B85BED6577A35B, r, g, b)
end
