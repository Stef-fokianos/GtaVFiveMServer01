function Global.ItemDatabaseGetBundleId(p0)
	return _in(0x891A45960B6B768A, p0, _r, _ri)
end
