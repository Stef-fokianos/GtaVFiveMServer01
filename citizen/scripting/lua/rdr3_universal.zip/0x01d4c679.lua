function Global.AddCustomFormationLocation(p0, p1, p2, p3, p4)
	return _in(0x4E23CD07BD161E06, p0, p1, p2, p3, p4)
end
