function Global.SetCargobobPickupMagnetReducedStrength(cargobob, vehicle)
	return _in(0xE301BD63E9E13CF0, cargobob, vehicle)
end
