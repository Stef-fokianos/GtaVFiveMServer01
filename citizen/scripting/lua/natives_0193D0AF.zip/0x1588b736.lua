function Global.GetIsVehicleSecondaryColourCustom(vehicle)
	return _in(0x910A32E7AAD2656C, vehicle, _r)
end
