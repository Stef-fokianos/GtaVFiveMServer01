function Global.ClearCloudHat()
	return _in(0x957E790EA1727B64)
end
