function Global.N_0x324ab2a68ad8aee5()
	return _in(0x324AB2A68AD8AEE5)
end
