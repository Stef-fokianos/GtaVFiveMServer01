function Global.ItemDatabaseGetHasSlotInfo(p0, p1, p2)
	return _in(0x8A9BD0DB7E8376CF, p0, p1, p2, _r, _ri)
end
