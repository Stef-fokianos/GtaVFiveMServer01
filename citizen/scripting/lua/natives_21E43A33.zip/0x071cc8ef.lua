function Global.N_0xf1ae5dcdbfca2721()
	return _in(0xF1AE5DCDBFCA2721, _i, _i, _i, _r)
end
