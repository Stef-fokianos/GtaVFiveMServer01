function Global.N_0xceec64bd27a59312(p0)
	return _in(0xCEEC64BD27A59312, p0, _r, _ri)
end
