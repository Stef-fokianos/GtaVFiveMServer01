function Global.N_0xeb2bf817463dfa28(p0, p1)
	return _in(0xEB2BF817463DFA28, p0, p1, _r, _ri)
end
