function Global.N_0x0e3a041ed6ac2b45()
	return _in(0x0E3A041ED6AC2B45, _r, _rf)
end
