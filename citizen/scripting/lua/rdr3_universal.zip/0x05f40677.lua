function Global.N_0x7ec0d68233e391ac(p0)
	return _in(0x7EC0D68233E391AC, p0, _r, _ri)
end
