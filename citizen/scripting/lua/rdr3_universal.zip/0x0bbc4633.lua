function Global.TaskAmbientAnimalStalk(p0, p1, p2)
	return _in(0x37C13863ABA1B4A3, p0, p1, p2)
end
