function Global.NetworkSpentProstitutes(p0, p1, p2)
	return _in(0xB21B89501CFAC79E, p0, p1, p2)
end
