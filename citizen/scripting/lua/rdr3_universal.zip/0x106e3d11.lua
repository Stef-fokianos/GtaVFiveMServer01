function Global.LocalizationGetSystemLanguage()
	return _in(0x3C1A05F86AE6ACB5, _r, _ri)
end
