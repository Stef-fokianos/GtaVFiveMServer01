function Global.TaskAmbientAnimalHunt(p0, p1, p2)
	return _in(0x4B39D8F9D0FE7749, p0, p1, p2)
end
