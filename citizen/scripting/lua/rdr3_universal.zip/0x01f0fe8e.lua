function Global.N_0xa95470da137587f5(p0)
	return _in(0xA95470DA137587F5, p0)
end
