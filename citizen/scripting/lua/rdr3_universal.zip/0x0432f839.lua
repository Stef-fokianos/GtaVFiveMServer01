function Global.N_0x08fc896d2cb31fcc(p0, p1)
	return _in(0x08FC896D2CB31FCC, p0, p1, _r, _ri)
end
