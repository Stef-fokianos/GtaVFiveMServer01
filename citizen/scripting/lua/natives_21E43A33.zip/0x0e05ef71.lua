function Global.DoesBlipExist(blip)
	return _in(0xA6DB27D19ECBB7DA, blip, _r)
end
