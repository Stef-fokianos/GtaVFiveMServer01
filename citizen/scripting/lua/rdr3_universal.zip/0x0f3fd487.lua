function Global.StopCamPointing(cam)
	return _in(0xCA1B30A3357C71F1, cam)
end
