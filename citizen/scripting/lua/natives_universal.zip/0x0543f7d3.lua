--- NativeDB Introduced: v1290
function Global.N_0x8410c5e0cd847b9d()
	return _in(0x8410C5E0CD847B9D)
end
