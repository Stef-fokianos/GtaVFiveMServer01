function Global.SetCamDofPlanes(cam, p1, p2, p3, p4)
	return _in(0x3CF48F6F96E749DC, cam, p1, p2, p3, p4)
end
