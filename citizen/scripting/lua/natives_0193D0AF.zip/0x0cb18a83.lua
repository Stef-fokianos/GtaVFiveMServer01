function Global.N_0x6e4361ff3e8cd7ca(p0)
	return _in(0x6E4361FF3E8CD7CA, p0, _r, _ri)
end
