function Global.NetworkGetDestroyerOfNetworkId(p0, p1)
	return _in(0x7A1ADEEF01740A24, p0, _ii(p1) --[[ may be optional ]], _r, _ri)
end
