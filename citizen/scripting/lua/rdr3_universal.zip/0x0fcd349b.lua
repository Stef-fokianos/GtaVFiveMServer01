function Global.N_0x6d87ba8ef15226cd()
	return _in(0x6D87BA8EF15226CD, _r, _ri)
end
