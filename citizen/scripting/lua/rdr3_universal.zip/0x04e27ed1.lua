function Global.N_0xaab86462966168ce(p0, p1)
	return _in(0xAAB86462966168CE, p0, p1, _r, _ri)
end
