function Global.N_0xa33914b00ca55756(p0, p1)
	return _in(0xA33914B00CA55756, p0, p1, _r, _ri)
end
