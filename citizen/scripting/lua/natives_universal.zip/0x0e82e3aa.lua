--- **This native does absolutely nothing, just a nullsub**
function Global.N_0xeb078ca2b5e82add(p0, p1)
	return _in(0xEB078CA2B5E82ADD, p0, p1)
end
