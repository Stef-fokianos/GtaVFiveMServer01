function Global.SetCinematicButtonActive(p0)
	return _in(0x51669F7D1FB53D9F, p0)
end
