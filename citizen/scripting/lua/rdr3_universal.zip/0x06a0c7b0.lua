function Global.N_0x5a498fca232f71e1(p0, p1)
	return _in(0x5A498FCA232F71E1, p0, p1)
end
