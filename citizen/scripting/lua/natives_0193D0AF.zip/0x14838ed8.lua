function Global.AudioIsScriptedMusicPlaying()
	return _in(0x845FFC3A4FEEFA3E, _r, _ri)
end
