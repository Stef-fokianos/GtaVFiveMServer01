function Global.EnableScriptBrainSet(p0)
	return _in(0x67AA4D73F0CFA86B, p0)
end
