function Global.N_0xd9c24f53631f2372(p0, p1, p2)
	return _in(0xD9C24F53631F2372, p0, p1, p2, _r, _ri)
end
