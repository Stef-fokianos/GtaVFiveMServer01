function Global.GetFinalRenderedInWhenFriendlyFov(player)
	return _in(0x5F35F6732C3FBBA0, player, _r, _rf)
end
