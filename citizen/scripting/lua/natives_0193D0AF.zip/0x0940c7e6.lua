function Global.ResetEditorValues()
	return _in(0x3353D13F09307691)
end
