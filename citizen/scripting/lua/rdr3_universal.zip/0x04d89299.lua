function Global.N_0x59643424b68d52b5(p0)
	return _in(0x59643424B68D52B5, p0, _r, _ri)
end
